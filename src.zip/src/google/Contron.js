import React from 'react'
import LindexGoogle from './LindexGoogle'
import Io from './Io'
import Time_Set from './Time_Set'
const Contron = () => {
    return (
        <div>
            <LindexGoogle />
            <Io />
            <Time_Set/>
        </div>
    )
}

export default Contron
import React from 'react'
import Index from './google/Man_tab'
const App = () => {
  return (
    <div  className="App">
      <div >
      <Index />
    </div> 
    </div>
   
  )
}

export default App